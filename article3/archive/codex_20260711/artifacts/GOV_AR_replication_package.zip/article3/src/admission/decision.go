package admission

import (
	"sort"

	"github.com/imperium/ai-sovereign-finops-operator/article3/src/ledger"
)

type Action string

const (
	ActionAdmit   Action = "admit"
	ActionQueue   Action = "queue"
	ActionReject  Action = "reject"
	ActionAbstain Action = "abstain"
)

type Candidate struct {
	Model              string
	UtilityScore       float64
	ReservationCost    float64
	GovernanceAllowed  bool
	TelemetryFresh     bool
	CalibrationTrusted bool
	EvidenceStrong     bool
	Drifted            bool
}

type Policy struct {
	StrictMode            bool
	AllowQueue            bool
	RequireFreshSignals   bool
	RequireStrongEvidence bool
	BlockOnDrift          bool
}

type Decision struct {
	Action         Action
	Model          string
	ReservationCost float64
	Reason         string
}

func Decide(policy Policy, tenant ledger.TenantState, candidates []Candidate) Decision {
	filtered := make([]Candidate, 0, len(candidates))
	missingEvidence := false
	for _, c := range candidates {
		if !c.GovernanceAllowed {
			continue
		}
		if policy.RequireFreshSignals && !c.TelemetryFresh {
			continue
		}
		if policy.StrictMode && !c.CalibrationTrusted {
			continue
		}
		if policy.RequireStrongEvidence && !c.EvidenceStrong {
			missingEvidence = true
			continue
		}
		if policy.BlockOnDrift && c.Drifted {
			missingEvidence = true
			continue
		}
		if tenant.Available() < c.ReservationCost {
			continue
		}
		filtered = append(filtered, c)
	}

	if len(filtered) == 0 {
		if missingEvidence {
			return Decision{Action: ActionAbstain, Reason: "insufficient evidence strength for a governed routing decision"}
		}
		if policy.AllowQueue {
			return Decision{Action: ActionQueue, Reason: "no feasible candidate under current budget or evidence constraints"}
		}
		return Decision{Action: ActionReject, Reason: "no feasible candidate under current budget or evidence constraints"}
	}

	sort.SliceStable(filtered, func(i, j int) bool {
		return filtered[i].UtilityScore > filtered[j].UtilityScore
	})
	best := filtered[0]
	return Decision{
		Action:          ActionAdmit,
		Model:           best.Model,
		ReservationCost: best.ReservationCost,
		Reason:          "highest utility among feasible candidates",
	}
}
