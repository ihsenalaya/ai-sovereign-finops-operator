# Kind Automation

Local reproducibility workflow:

```bash
bash article3/infra/kind/create_cluster.sh
bash article3/infra/kind/deploy_experiments.sh
kubectl -n gov-ar logs job/gov-ar-experiment
bash article3/infra/kind/destroy_cluster.sh
```

Useful overrides:

- `EXPERIMENT_COMMAND=e5`
- `IMAGE_REPO=gov-ar-experiment`
- `IMAGE_TAG=local`
- `CLUSTER_NAME=gov-ar`
