# Experiment Orchestrator

This directory contains the reproducible entrypoints used to execute and verify
the current GOV-AR experiment suite.

## Current scope

- `run_all.sh`: runs the implemented E0 to E5 plus E7 experiment chain end to end.
- `verify_outputs.sh`: validates that expected raw, processed, and report
  artifacts exist and remain parseable.

## Usage

From `article3/`:

```bash
bash experiments/orchestrator/run_all.sh
bash experiments/orchestrator/verify_outputs.sh
```

The current orchestrator covers the implemented scaffold for:

- `E0`
- `E1`
- `E2`
- `E3`
- `E4`
- `E5`
- `E7`
- `E1-campaign`
- `E2-campaign`
- `E1-matrix`
- `E2-matrix`
- `E1-compare`
- `E2-compare`

Pending experiment `E6` still needs its executable kernel.
